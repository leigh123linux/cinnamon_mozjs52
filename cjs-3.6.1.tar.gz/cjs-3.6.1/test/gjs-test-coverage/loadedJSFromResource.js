function mock_function() {}
