let i = 0;
if (i) {
    i = 1;
} else {
    i = 2;
}
