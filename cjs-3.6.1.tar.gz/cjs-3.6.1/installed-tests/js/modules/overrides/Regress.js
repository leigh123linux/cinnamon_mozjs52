// Sabotage the import of imports.gi.Regress!

function _init() {
    throw '💩';
}
