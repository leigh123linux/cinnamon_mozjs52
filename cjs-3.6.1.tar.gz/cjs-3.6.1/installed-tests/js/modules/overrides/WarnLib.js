// Sabotage the import of imports.gi.WarnLib!

k$^s^%$#^*($%jdghdsfjkgd
