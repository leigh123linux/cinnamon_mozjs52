// Sabotage the import of imports.gi.Gio!

var _init = '💩';
