// Sabotage the import of imports.gi.GIMarshallingTests!

throw '💩';
