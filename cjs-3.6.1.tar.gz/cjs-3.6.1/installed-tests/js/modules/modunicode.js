// This file is written in UTF-8.

const uval = "const ♥ utf8";
