const A = imports.mutualImport.a;

function getCount() {
    return A.getCount();
}

